function mensagemLoad(load)
    if(load >= 0)
        fprintf('\nCalculando... %3.2f%%', load * 100);
        if(load > 0)
            fprintf('\tTempo gasto: %f s', toc);
    end

    tic
end